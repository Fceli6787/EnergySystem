import view.ClienteForm;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestión de Clientes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 700);
        frame.setLocationRelativeTo(null);

        ClienteForm clienteForm = new ClienteForm();
        frame.add(clienteForm);

        frame.setVisible(true);
    }
}

