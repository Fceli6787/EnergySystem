import random
import csv
from datetime import datetime, timedelta

def generate_consumption_data():
    # Crear encabezados
    headers = ['hora', 'consumo_kwh', 'generacion_kwh']
    data = []
    
    # Generar datos para cada hora
    for hora in range(24):
        # Determinar el rango según la franja horaria
        if 0 <= hora <= 6:
            consumo = random.uniform(200, 300)
        elif 7 <= hora <= 17:
            consumo = random.uniform(500, 700)
        else:  # 18 a 23
            consumo = random.uniform(800, 1000)
            
        # Calcular generación (asumimos que es un 80% del consumo como ejemplo)
        generacion = consumo * 0.8
        
        # Formatear hora
        hora_str = f"{hora:02d}:00"
        
        # Agregar fila
        data.append([hora_str, round(consumo, 2), round(generacion, 2)])
    
    # Escribir en CSV
    with open('consumo_energia.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(headers)
        writer.writerows(data)
        
    # Calcular totales
    total_consumo = sum(row[1] for row in data)
    total_generacion = sum(row[2] for row in data)
    
    return data, total_consumo, total_generacion

# Ejecutar el generador
data, total_consumo, total_generacion = generate_consumption_data()

# Imprimir resultados
print("Archivo 'consumo_energia.csv' generado con éxito")
print(f"\nConsumo total: {round(total_consumo, 2)} kWh")
print(f"Generación total: {round(total_generacion, 2)} kWh")

# Mostrar primeras filas como ejemplo
print("\nPrimeras filas del archivo:")
print("Hora, Consumo (kWh), Generación (kWh)")
for row in data[:5]:
    print(f"{row[0]}, {row[1]}, {row[2]}")