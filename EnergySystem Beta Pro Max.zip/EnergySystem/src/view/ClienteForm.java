package view;

import controller.ClienteController;
import controller.GeneradorFacturaPDF;
import model.Cliente;
import model.Facturacion;
import util.DatabaseUtil;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ClienteForm extends JFrame {
    private JTextField telefonoField;
    private JTextField emailField;
    private JComboBox<String> tipoPersonaComboBox;
    private JTextField primerNombreField;
    private JTextField segundoNombreField;
    private JTextField primerApellidoField;
    private JTextField segundoApellidoField;
    private JTextField nuiField;
    private JTextField fechaNacimientoField;
    private JTextField razonSocialField;
    private JTextField nitField;
    private JTextField fechaCreacionField;
    private JTextField numeroContadorField;
    private JTextField marcaField;
    private JComboBox<String> tipoVia;
    private JTextField numeroPrincipal;
    private JTextField letraPrincipal;
    private JTextField numeroCruce;
    private JTextField letraCruce;
    private JTextField numeroCasa;
    private JTextField municipioField;
    private JTextField fechaInicioField;
    private JTextField fechaFinField;
    private Cliente cliente; // Declara la variable cliente como una variable de instancia

    public ClienteForm() {
        setTitle("Gestión de Clientes");
        setSize(900, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(null);

        // Campos comunes
        JLabel telefonoLabel = new JLabel("Teléfono:");
        telefonoLabel.setBounds(50, 30, 120, 30);
        panel.add(telefonoLabel);

        telefonoField = new JTextField();
        telefonoField.setBounds(180, 30, 200, 30);
        panel.add(telefonoField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 70, 120, 30);
        panel.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(180, 70, 200, 30);
        panel.add(emailField);

        JLabel tipoPersonaLabel = new JLabel("Tipo de Persona:");
        tipoPersonaLabel.setBounds(50, 110, 120, 30);
        panel.add(tipoPersonaLabel);

        tipoPersonaComboBox = new JComboBox<>();
        tipoPersonaComboBox.setBounds(180, 110, 200, 30);
        panel.add(tipoPersonaComboBox);

        // Cargar tipos de cliente desde la base de datos
        cargarTiposCliente();

        JLabel numeroContadorLabel = new JLabel("Número de Contador:");
        numeroContadorLabel.setBounds(50, 150, 150, 30);
        panel.add(numeroContadorLabel);

        numeroContadorField = new JTextField();
        numeroContadorField.setBounds(180, 150, 200, 30);
        panel.add(numeroContadorField);

        JLabel marcaLabel = new JLabel("Marca:");
        marcaLabel.setBounds(50, 190, 120, 30);
        panel.add(marcaLabel);

        marcaField = new JTextField();
        marcaField.setBounds(180, 190, 200, 30);
        panel.add(marcaField);

        // Tipo de vía
        JLabel tipoViaLabel = new JLabel("Tipo de vía:");
        tipoViaLabel.setBounds(50, 230, 120, 30);
        panel.add(tipoViaLabel);

        String[] tiposVia = {"Seleccione", "Calle", "Avenida", "Carrera", "Circunvalar", "Transversal", "Diagonal"};
        tipoVia = new JComboBox<>(tiposVia);
        tipoVia.setBounds(180, 230, 200, 30);
        panel.add(tipoVia);

        // Número principal
        JLabel numeroPrincipalLabel = new JLabel("Número principal:");
        numeroPrincipalLabel.setBounds(50, 270, 120, 30);
        panel.add(numeroPrincipalLabel);

        numeroPrincipal = new JTextField();
        numeroPrincipal.setBounds(180, 270, 200, 30);
        panel.add(numeroPrincipal);

        // Letra principal
        JLabel letraPrincipalLabel = new JLabel("Letra (si aplica):");
        letraPrincipalLabel.setBounds(50, 310, 120, 30);
        panel.add(letraPrincipalLabel);

        letraPrincipal = new JTextField();
        letraPrincipal.setBounds(180, 310, 200, 30);
        panel.add(letraPrincipal);

        // Número de cruce
        JLabel numeroCruceLabel = new JLabel("# Cruce:");
        numeroCruceLabel.setBounds(50, 350, 120, 30);
        panel.add(numeroCruceLabel);

        numeroCruce = new JTextField();
        numeroCruce.setBounds(180, 350, 200, 30);
        panel.add(numeroCruce);

        // Letra de cruce
        JLabel letraCruceLabel = new JLabel("Letra cruce (si aplica):");
        letraCruceLabel.setBounds(50, 390, 120, 30);
        panel.add(letraCruceLabel);

        letraCruce = new JTextField();
        letraCruce.setBounds(180, 390, 200, 30);
        panel.add(letraCruce);

        // Número final
        JLabel numeroCasaLabel = new JLabel("Número final:");
        numeroCasaLabel.setBounds(50, 430, 120, 30);
        panel.add(numeroCasaLabel);

        numeroCasa = new JTextField();
        numeroCasa.setBounds(180, 430, 200, 30);
        panel.add(numeroCasa);

        JLabel municipioLabel = new JLabel("Municipio:");
        municipioLabel.setBounds(50, 470, 120, 30);
        panel.add(municipioLabel);

        municipioField = new JTextField();
        municipioField.setBounds(180, 470, 200, 30);
        panel.add(municipioField);

        // Campos Persona Natural
        JLabel primerNombreLabel = new JLabel("Primer Nombre:");
        primerNombreLabel.setBounds(450, 30, 150, 30);
        panel.add(primerNombreLabel);

        primerNombreField = new JTextField();
        primerNombreField.setBounds(600, 30, 200, 30);
        panel.add(primerNombreField);

        JLabel segundoNombreLabel = new JLabel("Segundo Nombre:");
        segundoNombreLabel.setBounds(450, 70, 150, 30);
        panel.add(segundoNombreLabel);

        segundoNombreField = new JTextField();
        segundoNombreField.setBounds(600, 70, 200, 30);
        panel.add(segundoNombreField);

        JLabel primerApellidoLabel = new JLabel("Primer Apellido:");
        primerApellidoLabel.setBounds(450, 110, 150, 30);
        panel.add(primerApellidoLabel);

        primerApellidoField = new JTextField();
        primerApellidoField.setBounds(600, 110, 200, 30);
        panel.add(primerApellidoField);

        JLabel segundoApellidoLabel = new JLabel("Segundo Apellido:");
        segundoApellidoLabel.setBounds(450, 150, 150, 30);
        panel.add(segundoApellidoLabel);

        segundoApellidoField = new JTextField();
        segundoApellidoField.setBounds(600, 150, 200, 30);
        panel.add(segundoApellidoField);

        JLabel nuiLabel = new JLabel("NUI:");
        nuiLabel.setBounds(450, 190, 150, 30);
        panel.add(nuiLabel);

        nuiField = new JTextField();
        nuiField.setBounds(600, 190, 200, 30);
        panel.add(nuiField);

        JLabel fechaNacimientoLabel = new JLabel("Fecha Nacimiento:");
        fechaNacimientoLabel.setBounds(450, 230, 150, 30);
        panel.add(fechaNacimientoLabel);

        fechaNacimientoField = new JTextField();
        fechaNacimientoField.setBounds(600, 230, 200, 30);
        panel.add(fechaNacimientoField);

        // Campos Persona Jurídica
        JLabel razonSocialLabel = new JLabel("Razón Social:");
        razonSocialLabel.setBounds(450, 270, 150, 30);
        panel.add(razonSocialLabel);

        razonSocialField = new JTextField();
        razonSocialField.setBounds(600, 270, 200, 30);
        panel.add(razonSocialField);

        JLabel nitLabel = new JLabel("NIT:");
        nitLabel.setBounds(450, 310, 150, 30);
        panel.add(nitLabel);

        nitField = new JTextField();
        nitField.setBounds(600, 310, 200, 30);
        panel.add(nitField);

        JLabel fechaCreacionLabel = new JLabel("Fecha Creación:");
        fechaCreacionLabel.setBounds(450, 350, 150, 30);
        panel.add(fechaCreacionLabel);

        fechaCreacionField = new JTextField();
        fechaCreacionField.setBounds(600, 350, 200, 30);
        panel.add(fechaCreacionField);

        // Campos para fechas de facturación
        JLabel fechaInicioLabel = new JLabel("Fecha Inicio:");
        fechaInicioLabel.setBounds(50, 510, 120, 30);
        panel.add(fechaInicioLabel);

        fechaInicioField = new JTextField();
        fechaInicioField.setBounds(180, 510, 200, 30);
        panel.add(fechaInicioField);

        JLabel fechaFinLabel = new JLabel("Fecha Fin:");
        fechaFinLabel.setBounds(50, 550, 120, 30);
        panel.add(fechaFinLabel);

        fechaFinField = new JTextField();
        fechaFinField.setBounds(180, 550, 200, 30);
        panel.add(fechaFinField);

        // Botones reorganizados
        JPanel botonesPanel = new JPanel();
        botonesPanel.setBounds(50, 600, 800, 50);
        botonesPanel.setLayout(new GridLayout(1, 4, 20, 0));

        JButton addButton = new JButton("Agregar Cliente");
        botonesPanel.add(addButton);

        // Botón Descargar Recibo
        JButton descargarReciboButton = new JButton("Descargar Recibo");
        botonesPanel.add(descargarReciboButton);

        // Botón Generar PDF
        JButton generarPDFButton = new JButton("Generar PDF");
        botonesPanel.add(generarPDFButton);

        // Botón Cargar CSV
        JButton cargarCSVButton = new JButton("Cargar CSV");
        botonesPanel.add(cargarCSVButton);

        panel.add(botonesPanel);

        // Acción para el botón Agregar Cliente
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validarCampos()) {
                    cliente = new Cliente(); // Asigna el objeto cliente
                    cliente.setTipoCliente((String) tipoPersonaComboBox.getSelectedItem());
                    cliente.setPrimerNombre(primerNombreField.getText());
                    cliente.setSegundoNombre(segundoNombreField.getText().isEmpty() ? null : segundoNombreField.getText());
                    cliente.setPrimerApellido(primerApellidoField.getText());
                    cliente.setSegundoApellido(segundoApellidoField.getText().isEmpty() ? null : segundoApellidoField.getText());
                    cliente.setTipoIdentificacion(nuiField.getText());
                    cliente.setNUI(nuiField.getText());
                    cliente.setFechaNacimiento(parseDate(fechaNacimientoField.getText()));
                    cliente.setRazonSocial(razonSocialField.getText());
                    cliente.setNIT(nitField.getText());
                    cliente.setFechaCreacion(parseDate(fechaCreacionField.getText()));
                    cliente.setCelular(telefonoField.getText());
                    cliente.setCorreo(emailField.getText());
                    cliente.setClienteDireccion(
                            tipoVia.getSelectedItem() + " " +
                            numeroPrincipal.getText() + " " +
                            letraPrincipal.getText() + " " +
                            numeroCruce.getText() + " " +
                            letraCruce.getText() + " " +
                            numeroCasa.getText() + " " +
                            municipioField.getText()
                    );

                    try {
                        ClienteController.addCliente(cliente);
                        JOptionPane.showMessageDialog(null, "Cliente agregado exitosamente");
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Error al agregar cliente: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos obligatorios.");
                }
            }
        });

        // Acción para el botón Generar PDF
        generarPDFButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (validarCampos()) {
                    String fechaInicio = parseDate(fechaInicioField.getText());
                    String fechaFin = parseDate(fechaFinField.getText());

                    // Aquí deberías obtener las facturas del cliente en el rango de fechas especificado
                    List<Facturacion> facturas = obtenerFacturasPorFecha(fechaInicio, fechaFin);

                    if (facturas != null && !facturas.isEmpty()) {
                        // Obtener el contrato_id del cliente
                        int contratoId = obtenerContratoIdPorCliente(cliente);

                        if (contratoId != -1) {
                            GeneradorFacturaPDF facturaPDF = new GeneradorFacturaPDF();
                            facturaPDF.generarFactura(contratoId, facturas, "factura.pdf");
                            JOptionPane.showMessageDialog(null, "PDF generado exitosamente");
                        } else {
                            JOptionPane.showMessageDialog(null, "No se encontró el contrato para el cliente especificado");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay facturas disponibles para el rango de fechas especificado");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos obligatorios.");
                }
            }
        });

        // Acción para el botón Cargar CSV
        cargarCSVButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Seleccionar archivo CSV");
                fileChooser.setFileFilter(new FileNameExtensionFilter("Archivos CSV", "csv"));

                int userSelection = fileChooser.showOpenDialog(null);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToUpload = fileChooser.getSelectedFile();
                    String filePath = fileToUpload.getAbsolutePath();

                    // Solicitar el nombre de la tabla
                    String tableName = JOptionPane.showInputDialog(null, "Ingrese el nombre de la tabla:");

                    if (tableName != null && !tableName.trim().isEmpty()) {
                        cargarCSVEnBaseDeDatos(filePath, tableName);
                    } else {
                        JOptionPane.showMessageDialog(null, "Debe ingresar un nombre de tabla válido.");
                    }
                }
            }
        });

        // Acción para el combo box de tipo de persona
        tipoPersonaComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipoPersona = (String) tipoPersonaComboBox.getSelectedItem();
                if ("Persona Natural".equals(tipoPersona)) {
                    habilitarCamposPersonaNatural();
                    deshabilitarCamposPersonaJuridica();
                } else if ("Persona Jurídica".equals(tipoPersona)) {
                    habilitarCamposPersonaJuridica();
                    deshabilitarCamposPersonaNatural();
                }
            }
        });

        add(panel);
        setVisible(true);
    }

    // Método para cargar los tipos de cliente desde la base de datos
    private void cargarTiposCliente() {
        String sql = "SELECT DISTINCT tipo_cliente FROM clientes";
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            // Always add "Seleccione" first
            tipoPersonaComboBox.addItem("Seleccione");

            System.out.println("Cargando tipos de cliente desde la base de datos...");
            while (rs.next()) {
                String tipoCliente = rs.getString("tipo_cliente");
                System.out.println("Tipo de cliente cargado: " + tipoCliente);
                tipoPersonaComboBox.addItem(tipoCliente);
            }

            // If no types are found, add default types
            if (tipoPersonaComboBox.getItemCount() == 1) { // "Seleccione" is already added
                System.out.println("No se encontraron tipos de cliente en la base de datos. Añadiendo valores por defecto.");
                tipoPersonaComboBox.addItem("Persona Natural");
                tipoPersonaComboBox.addItem("Persona Jurídica");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al cargar los tipos de cliente: " + e.getMessage());
        }
    }

    private void cargarCSVEnBaseDeDatos(String filePath, String tableName) {
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             BufferedReader br = new BufferedReader(new FileReader(filePath))) {

            String firstLine = br.readLine();
            String[] columnNames = firstLine.split(",");

            // Determinar la tabla según las columnas
            String determinedTableName = determineTableFromColumns(columnNames);

            if (determinedTableName.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No se pudo determinar la tabla en la que cargar los datos.");
                return;
            }

            String query = String.format(
                "LOAD DATA LOCAL INFILE '%s' " +
                "INTO TABLE %s " +
                "FIELDS TERMINATED BY ',' ENCLOSED BY '\"' " +
                "LINES TERMINATED BY '\\n' " +
                "IGNORE 1 LINES " +
                "(%s)",
                filePath.replace("\\", "\\\\"), determinedTableName, getColumnsForTable(determinedTableName)
            );

            System.out.println("Consulta SQL: " + query);

            stmt.execute(query);

            JOptionPane.showMessageDialog(null, "CSV cargado exitosamente en la base de datos en la tabla " + determinedTableName);
        } catch (SQLException e) {
            e.printStackTrace(); // Imprime la excepción para depurar
            JOptionPane.showMessageDialog(null, "Error al cargar el CSV en la base de datos: " + e.getMessage());
        } catch (IOException e) {
            e.printStackTrace(); // Imprime la excepción para depurar
            JOptionPane.showMessageDialog(null, "Error al leer el archivo CSV: " + e.getMessage());
        }
    }

    private String getColumnsForTable(String tableName) {
        switch (tableName.toLowerCase()) {
            case "clientes":
                return "cliente_id, tipo_cliente, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, tipo_identificacion, NUI, fecha_nacimiento, razon_social, NIT, fecha_creacion, celular, correo, cliente_direccion";
            case "franjaprecios":
                return "franja_id, hora_inicio, hora_finalizacion, precio_piso, precio_techo";
            case "region":
                return "region_id, region_nombre";
            case "departamentos":
                return "departamento_id, departamento_nombre, region_region_id";
            case "municipios":
                return "municipio_id, municipio_nombre, departamentos_departamento_id";
            case "direccion":
                return "direccion_id, municipios_municipio_id, ubicacion, codigo_postal";
            case "contratos":
                return "contrato_id, direccion_contrato, fecha_inicio, fecha_fin, valor_kwh, clientes_cliente_id, direccion_direccion_id";
            case "consumos":
                return "consumo_id, fecha_inicio, fecha_finalizacion, kwh_totales";
            case "contador":
                return "contador_id, marca_contador, fecha_instalacion, modelo_contador";
            case "facturacion":
                return "facturacion_id, fecha_factura, total_kwh, total_cobro, contratos_contrato_id, consumos_consumo_id, contador_contador_id, franjaPrecios_franja_id";
            default:
                return "";
        }
    }

    private String determineTableFromColumns(String[] columnNames) {
        // Define las columnas que esperas para cada tabla
        String[] clientesColumns = {"cliente_id", "tipo_cliente", "primer_nombre", "segundo_nombre", "primer_apellido", "segundo_apellido", "tipo_identificacion", "NUI", "fecha_nacimiento", "razon_social", "NIT", "fecha_creacion", "celular", "correo", "cliente_direccion"};
        String[] franjaPreciosColumns = {"franja_id", "hora_inicio", "hora_finalizacion", "precio_piso", "precio_techo"};
        String[] regionColumns = {"region_id", "region_nombre"};
        String[] departamentosColumns = {"departamento_id", "departamento_nombre", "region_region_id"};
        String[] municipiosColumns = {"municipio_id", "municipio_nombre", "departamentos_departamento_id"};
        String[] direccionColumns = {"direccion_id", "municipios_municipio_id", "ubicacion", "codigo_postal"};
        String[] contratosColumns = {"contrato_id", "direccion_contrato", "fecha_inicio", "fecha_fin", "valor_kwh", "clientes_cliente_id", "direccion_direccion_id"};
        String[] consumosColumns = {"consumo_id", "fecha_inicio", "fecha_finalizacion", "kwh_totales"};
        String[] contadorColumns = {"contador_id", "marca_contador", "fecha_instalacion", "modelo_contador"};
        String[] facturacionColumns = {"facturacion_id", "fecha_factura", "total_kwh", "total_cobro", "contratos_contrato_id", "consumos_consumo_id", "contador_contador_id", "franjaPrecios_franja_id"};

        if (matchesColumns(columnNames, clientesColumns)) {
            return "clientes";
        } else if (matchesColumns(columnNames, franjaPreciosColumns)) {
            return "franjaprecios";
        } else if (matchesColumns(columnNames, regionColumns)) {
            return "region";
        } else if (matchesColumns(columnNames, departamentosColumns)) {
            return "departamentos";
        } else if (matchesColumns(columnNames, municipiosColumns)) {
            return "municipios";
        } else if (matchesColumns(columnNames, direccionColumns)) {
            return "direccion";
        } else if (matchesColumns(columnNames, contratosColumns)) {
            return "contratos";
        } else if (matchesColumns(columnNames, consumosColumns)) {
            return "consumos";
        } else if (matchesColumns(columnNames, contadorColumns)) {
            return "contador";
        } else if (matchesColumns(columnNames, facturacionColumns)) {
            return "facturacion";
        } else {
            return "";
        }
    }

    private boolean matchesColumns(String[] columnNames, String[] expectedColumns) {
        if (columnNames.length != expectedColumns.length) {
            return false;
        }
        for (String column : columnNames) {
            if (!containsColumn(expectedColumns, column)) {
                return false;
            }
        }
        return true;
    }

    private boolean containsColumn(String[] expectedColumns, String column) {
        for (String expectedColumn : expectedColumns) {
            if (expectedColumn.equalsIgnoreCase(column)) {
                return true;
            }
        }
        return false;
    }

    // Método para validar que todos los campos obligatorios estén completos
    private boolean validarCampos() {
        if (telefonoField.getText().isEmpty() || emailField.getText().isEmpty() ||
            tipoPersonaComboBox.getSelectedItem() == null ||
            numeroContadorField.getText().isEmpty() || marcaField.getText().isEmpty() ||
            tipoVia.getSelectedItem() == null || numeroPrincipal.getText().isEmpty() ||
            municipioField.getText().isEmpty()) {
            return false;
        }

        if ("Persona Natural".equals(tipoPersonaComboBox.getSelectedItem())) {
            // Solo validamos primer nombre y primer apellido como obligatorios
            if (primerNombreField.getText().isEmpty() ||
                primerApellidoField.getText().isEmpty() ||
                nuiField.getText().isEmpty() ||
                fechaNacimientoField.getText().isEmpty()) {
                return false;
            }
        } else if ("Persona Jurídica".equals(tipoPersonaComboBox.getSelectedItem())) {
            if (razonSocialField.getText().isEmpty() ||
                nitField.getText().isEmpty() ||
                fechaCreacionField.getText().isEmpty()) {
                return false;
            }
        }

        return true;
    }

    // Método para habilitar campos de persona natural
    private void habilitarCamposPersonaNatural() {
        primerNombreField.setEnabled(true);
        segundoNombreField.setEnabled(true);
        primerApellidoField.setEnabled(true);
        segundoApellidoField.setEnabled(true);
        nuiField.setEnabled(true);
        fechaNacimientoField.setEnabled(true);

        razonSocialField.setEnabled(false);
        nitField.setEnabled(false);
        fechaCreacionField.setEnabled(false);

        primerNombreField.setBackground(Color.WHITE);
        segundoNombreField.setBackground(Color.WHITE);
        primerApellidoField.setBackground(Color.WHITE);
        segundoApellidoField.setBackground(Color.WHITE);
        nuiField.setBackground(Color.WHITE);
        fechaNacimientoField.setBackground(Color.WHITE);

        razonSocialField.setBackground(Color.GRAY);
        nitField.setBackground(Color.GRAY);
        fechaCreacionField.setBackground(Color.GRAY);
    }

    // Método para deshabilitar campos de persona natural
    private void deshabilitarCamposPersonaNatural() {
        primerNombreField.setEnabled(false);
        segundoNombreField.setEnabled(false);
        primerApellidoField.setEnabled(false);
        segundoApellidoField.setEnabled(false);
        nuiField.setEnabled(false);
        fechaNacimientoField.setEnabled(false);

        primerNombreField.setBackground(Color.GRAY);
        segundoNombreField.setBackground(Color.GRAY);
        primerApellidoField.setBackground(Color.GRAY);
        segundoApellidoField.setBackground(Color.GRAY);
        nuiField.setBackground(Color.GRAY);
        fechaNacimientoField.setBackground(Color.GRAY);
    }

    // Método para habilitar campos de persona jurídica
    private void habilitarCamposPersonaJuridica() {
        razonSocialField.setEnabled(true);
        nitField.setEnabled(true);
        fechaCreacionField.setEnabled(true);

        primerNombreField.setEnabled(false);
        segundoNombreField.setEnabled(false);
        primerApellidoField.setEnabled(false);
        segundoApellidoField.setEnabled(false);
        nuiField.setEnabled(false);
        fechaNacimientoField.setEnabled(false);

        razonSocialField.setBackground(Color.WHITE);
        nitField.setBackground(Color.WHITE);
        fechaCreacionField.setBackground(Color.WHITE);

        primerNombreField.setBackground(Color.GRAY);
        segundoNombreField.setBackground(Color.GRAY);
        primerApellidoField.setBackground(Color.GRAY);
        segundoApellidoField.setBackground(Color.GRAY);
        nuiField.setBackground(Color.GRAY);
        fechaNacimientoField.setBackground(Color.GRAY);
    }

    // Método para deshabilitar campos de persona jurídica
    private void deshabilitarCamposPersonaJuridica() {
        razonSocialField.setEnabled(false);
        nitField.setEnabled(false);
        fechaCreacionField.setEnabled(false);

        razonSocialField.setBackground(Color.GRAY);
        nitField.setBackground(Color.GRAY);
        fechaCreacionField.setBackground(Color.GRAY);
    }

    // Método para parsear y formatear fechas
    private String parseDate(String date) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date parsedDate = inputFormat.parse(date);
            return outputFormat.format(parsedDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Método para obtener las facturas del cliente en el rango de fechas especificado
    private List<Facturacion> obtenerFacturasPorFecha(String fechaInicio, String fechaFin) {
        List<Facturacion> facturas = new ArrayList<>();
        String sql = "SELECT * FROM facturacion WHERE fecha_factura BETWEEN ? AND ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, fechaInicio);
            pstmt.setString(2, fechaFin);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    Facturacion factura = new Facturacion();
                    factura.setFacturacion_id(rs.getInt("facturacion_id"));
                    factura.setFecha_factura(rs.getDate("fecha_factura"));
                    factura.setTotal_kwh(rs.getBigDecimal("total_kwh"));
                    factura.setTotal_cobro(rs.getBigDecimal("total_cobro"));
                    facturas.add(factura);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return facturas;
    }

    // Método para obtener el contrato_id del cliente
    private int obtenerContratoIdPorCliente(Cliente cliente) {
        String sql = "SELECT contrato_id FROM contratos WHERE clientes_cliente_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cliente.getIdCliente());
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("contrato_id");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
