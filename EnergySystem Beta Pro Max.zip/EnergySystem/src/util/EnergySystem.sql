-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema EnergySystem
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema EnergySystem
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `EnergySystem` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci ;
USE `EnergySystem` ;

-- -----------------------------------------------------
-- Table `EnergySystem`.`clientes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`clientes` (
  `cliente_id` INT NOT NULL AUTO_INCREMENT,
  `tipo_cliente` VARCHAR(45) NOT NULL,
  `primer_nombre` VARCHAR(45) NULL,
  `segundo_nombre` VARCHAR(45) NULL,
  `primer_apellido` VARCHAR(45) NULL,
  `segundo_apellido` VARCHAR(45) NULL,
  `tipo_identificacion` VARCHAR(45) NULL,
  `NUI` VARCHAR(45) NULL,
  `fecha_nacimiento` DATE NULL,
  `razon_social` VARCHAR(45) NULL,
  `NIT` VARCHAR(45) NULL,
  `fecha_creacion` DATE NULL,
  `celular` VARCHAR(45) NOT NULL,
  `correo` VARCHAR(45) NOT NULL,
  `cliente_direccion` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cliente_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`franjaPrecios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`franjaPrecios` (
  `franja_id` INT NOT NULL AUTO_INCREMENT,
  `hora_inicio` TIME NOT NULL,
  `hora_finalizacion` TIME NOT NULL,
  `precio_piso` DECIMAL(8,2) NOT NULL,
  `precio_techo` DECIMAL(8,2) NOT NULL,
  PRIMARY KEY (`franja_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`region`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`region` (
  `region_id` INT NOT NULL AUTO_INCREMENT,
  `region_nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`region_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`departamentos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`departamentos` (
  `departamento_id` INT NOT NULL AUTO_INCREMENT,
  `departamento_nombre` VARCHAR(45) NOT NULL,
  `region_region_id` INT NOT NULL,
  PRIMARY KEY (`departamento_id`, `region_region_id`),
  INDEX `fk_departamentos_region1_idx` (`region_region_id` ASC),
  CONSTRAINT `fk_departamentos_region1`
    FOREIGN KEY (`region_region_id`)
    REFERENCES `EnergySystem`.`region` (`region_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`municipios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`municipios` (
  `municipio_id` INT NOT NULL AUTO_INCREMENT,
  `municipio_nombre` VARCHAR(45) NOT NULL,
  `departamentos_departamento_id` INT NOT NULL,
  PRIMARY KEY (`municipio_id`, `departamentos_departamento_id`),
  INDEX `fk_municipios_departamentos_idx` (`departamentos_departamento_id` ASC),
  CONSTRAINT `fk_municipios_departamentos`
    FOREIGN KEY (`departamentos_departamento_id`)
    REFERENCES `EnergySystem`.`departamentos` (`departamento_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`direccion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`direccion` (
  `direccion_id` INT NOT NULL AUTO_INCREMENT,
  `municipios_municipio_id` INT NOT NULL,
  `ubicacion` VARCHAR(45) NOT NULL,
  `codigo_postal` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`direccion_id`, `municipios_municipio_id`),
  INDEX `fk_ubicacion_municipios1_idx` (`municipios_municipio_id` ASC),
  CONSTRAINT `fk_ubicacion_municipios1`
    FOREIGN KEY (`municipios_municipio_id`)
    REFERENCES `EnergySystem`.`municipios` (`municipio_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`contratos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`contratos` (
  `contrato_id` INT NOT NULL AUTO_INCREMENT,
  `direccion_contrato` VARCHAR(100) NOT NULL,
  `fecha_inicio` DATE NOT NULL,
  `fecha_fin` DATE NOT NULL,
  `valor_kwh` DECIMAL(10,2) NOT NULL,
  `clientes_cliente_id` INT NOT NULL,
  `direccion_direccion_id` INT NOT NULL,
  PRIMARY KEY (`contrato_id`, `clientes_cliente_id`, `direccion_direccion_id`),
  INDEX `fk_contratos_clientes1_idx` (`clientes_cliente_id` ASC),
  INDEX `fk_contratos_direccion1_idx` (`direccion_direccion_id` ASC),
  CONSTRAINT `fk_contratos_clientes1`
    FOREIGN KEY (`clientes_cliente_id`)
    REFERENCES `EnergySystem`.`clientes` (`cliente_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_contratos_direccion1`
    FOREIGN KEY (`direccion_direccion_id`)
    REFERENCES `EnergySystem`.`direccion` (`direccion_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`consumos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`consumos` (
  `consumo_id` INT NOT NULL AUTO_INCREMENT,
  `fecha_inicio` DATETIME NOT NULL,
  `fecha_finalizacion` DATETIME NOT NULL,
  `kwh_totales` DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`consumo_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`contador`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`contador` (
  `contador_id` INT NOT NULL AUTO_INCREMENT,
  `marca_contador` VARCHAR(45) NOT NULL,
  `fecha_instalacion` DATE NOT NULL,
  `modelo_contador` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`contador_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EnergySystem`.`facturacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `EnergySystem`.`facturacion` (
  `facturacion_id` INT NOT NULL,
  `fecha_factura` DATE NOT NULL,
  `total_kwh` DECIMAL(10,2) NOT NULL,
  `total_cobro` DECIMAL(10,2) NOT NULL,
  `contratos_contrato_id` INT NOT NULL,
  `consumos_consumo_id` INT NOT NULL,
  `contador_contador_id` INT NOT NULL,
  `franjaPrecios_franja_id` INT NOT NULL,
  PRIMARY KEY (`facturacion_id`, `contratos_contrato_id`, `consumos_consumo_id`, `contador_contador_id`, `franjaPrecios_franja_id`),
  INDEX `fk_facturacion_contratos1_idx` (`contratos_contrato_id` ASC),
  INDEX `fk_facturacion_consumos1_idx` (`consumos_consumo_id` ASC),
  INDEX `fk_facturacion_contador1_idx` (`contador_contador_id` ASC),
  INDEX `fk_facturacion_franjaPrecios1_idx` (`franjaPrecios_franja_id` ASC),
  CONSTRAINT `fk_facturacion_contratos1`
    FOREIGN KEY (`contratos_contrato_id`)
    REFERENCES `EnergySystem`.`contratos` (`contrato_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_facturacion_consumos1`
    FOREIGN KEY (`consumos_consumo_id`)
    REFERENCES `EnergySystem`.`consumos` (`consumo_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_facturacion_contador1`
    FOREIGN KEY (`contador_contador_id`)
    REFERENCES `EnergySystem`.`contador` (`contador_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_facturacion_franjaPrecios1`
    FOREIGN KEY (`franjaPrecios_franja_id`)
    REFERENCES `EnergySystem`.`franjaPrecios` (`franja_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
