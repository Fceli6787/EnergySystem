package model;

import java.math.BigDecimal;
import java.util.Date;

public class ValorKWh {
    private int idValorKWh;
    private Franja franja;
    private BigDecimal valorPiso;
    private BigDecimal valorTecho;
    private Date fecha;

    // Getters y setters
    public int getIdValorKWh() {
        return idValorKWh;
    }

    public void setIdValorKWh(int idValorKWh) {
        this.idValorKWh = idValorKWh;
    }

    public Franja getFranja() {
        return franja;
    }

    public void setFranja(Franja franja) {
        this.franja = franja;
    }

    public BigDecimal getValorPiso() {
        return valorPiso;
    }

    public void setValorPiso(BigDecimal valorPiso) {
        this.valorPiso = valorPiso;
    }

    public BigDecimal getValorTecho() {
        return valorTecho;
    }

    public void setValorTecho(BigDecimal valorTecho) {
        this.valorTecho = valorTecho;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
