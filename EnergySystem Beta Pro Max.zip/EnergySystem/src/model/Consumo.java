package model;

import java.math.BigDecimal;
import java.util.Date;

public class Consumo {
    private int idConsumo;
    private Date fecha;
    private BigDecimal consumoKWh;

    // Getters y setters
    public int getIdConsumo() {
        return idConsumo;
    }

    public void setIdConsumo(int idConsumo) {
        this.idConsumo = idConsumo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public BigDecimal getConsumoKWh() {
        return consumoKWh;
    }

    public void setConsumoKWh(BigDecimal consumoKWh) {
        this.consumoKWh = consumoKWh;
    }
}
