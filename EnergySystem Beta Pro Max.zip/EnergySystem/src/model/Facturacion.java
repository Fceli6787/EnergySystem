package model;

import java.math.BigDecimal;
import java.util.Date;

public class Facturacion {
    private int facturacion_id;
    private Date fecha_factura;
    private BigDecimal total_kwh;
    private BigDecimal total_cobro;

    // Getters y setters
    public int getFacturacion_id() {
        return facturacion_id;
    }

    public void setFacturacion_id(int facturacion_id) {
        this.facturacion_id = facturacion_id;
    }

    public Date getFecha_factura() {
        return fecha_factura;
    }

    public void setFecha_factura(Date fecha_factura) {
        this.fecha_factura = fecha_factura;
    }

    public BigDecimal getTotal_kwh() {
        return total_kwh;
    }

    public void setTotal_kwh(BigDecimal total_kwh) {
        this.total_kwh = total_kwh;
    }

    public BigDecimal getTotal_cobro() {
        return total_cobro;
    }

    public void setTotal_cobro(BigDecimal total_cobro) {
        this.total_cobro = total_cobro;
    }
}
