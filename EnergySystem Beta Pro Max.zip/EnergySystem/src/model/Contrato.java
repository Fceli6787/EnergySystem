package model;

public class Contrato {
    private int idCuentaContrato;
    private Cliente cliente;

    // Getters y setters
    public int getIdCuentaContrato() {
        return idCuentaContrato;
    }

    public void setIdCuentaContrato(int idCuentaContrato) {
        this.idCuentaContrato = idCuentaContrato;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
