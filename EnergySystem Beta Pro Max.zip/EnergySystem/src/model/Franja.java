package model;

public class Franja {
    private int idFranja;
    private String tipoFranja;

    // Getters y setters
    public int getIdFranja() {
        return idFranja;
    }

    public void setIdFranja(int idFranja) {
        this.idFranja = idFranja;
    }

    public String getTipoFranja() {
        return tipoFranja;
    }

    public void setTipoFranja(String tipoFranja) {
        this.tipoFranja = tipoFranja;
    }
}
