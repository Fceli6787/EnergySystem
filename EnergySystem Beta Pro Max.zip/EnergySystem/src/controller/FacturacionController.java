package controller;

import model.Facturacion;
import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;

public class FacturacionController {

    public static void addFacturacion(Facturacion facturacion) throws SQLException {
        String sql = "INSERT INTO Facturacion (fecha_factura, total_kwh) VALUES (?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, new Date(facturacion.getFecha_factura().getTime()));
            pstmt.setBigDecimal(2, facturacion.getTotal_kwh());
            pstmt.executeUpdate();
        }
    }

    public static void updateFacturacion(Facturacion facturacion) throws SQLException {
        String sql = "UPDATE Facturacion SET fecha_factura = ?, total_kwh = ? WHERE facturacion_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, new Date(facturacion.getFecha_factura().getTime()));
            pstmt.setBigDecimal(2, facturacion.getTotal_kwh());
            pstmt.setInt(3, facturacion.getFacturacion_id());
            pstmt.executeUpdate();
        }
    }
}
