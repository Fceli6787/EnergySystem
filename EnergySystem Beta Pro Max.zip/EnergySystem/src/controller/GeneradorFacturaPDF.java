package controller;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import model.Cliente;
import model.Facturacion;
import util.DatabaseUtil;

public class GeneradorFacturaPDF {

    // Método para generar un PDF para un cliente específico
    public void generarFactura(int contratoId, List<Facturacion> facturas, String rutaArchivo) {
        Cliente cliente = obtenerClientePorContratoId(contratoId);

        if (cliente != null) {
            try (PDDocument document = new PDDocument()) {
                PDPage page = new PDPage();
                document.addPage(page);

                try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                    // Configurar la fuente para el título
                    contentStream.setFont(PDType1Font.TIMES_BOLD, 16);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, 750);
                    contentStream.showText("Factura Mensual de Energía");
                    contentStream.endText();

                    // Configurar la fuente para el contenido
                    contentStream.setFont(PDType1Font.TIMES_ROMAN, 12);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, 730);
                    contentStream.showText("ID Cliente: " + cliente.getIdCliente());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Teléfono: " + cliente.getCelular());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Email: " + cliente.getCorreo());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Tipo de Persona: " + cliente.getTipoCliente());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Primer Nombre: " + cliente.getPrimerNombre());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Segundo Nombre: " + cliente.getSegundoNombre());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Primer Apellido: " + cliente.getPrimerApellido());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Segundo Apellido: " + cliente.getSegundoApellido());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Tipo de Identificación: " + cliente.getTipoIdentificacion());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("NUI: " + cliente.getNUI());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Fecha de Nacimiento: " + cliente.getFechaNacimiento());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Razón Social: " + cliente.getRazonSocial());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("NIT: " + cliente.getNIT());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Fecha de Creación: " + cliente.getFechaCreacion());
                    contentStream.newLineAtOffset(0, -20);
                    contentStream.showText("Dirección: " + cliente.getClienteDireccion());
                    contentStream.endText();

                    // Tabla de facturación
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, 500);
                    contentStream.showText("ID Factura");
                    contentStream.newLineAtOffset(100, 0);
                    contentStream.showText("Fecha");
                    contentStream.newLineAtOffset(100, 0);
                    contentStream.showText("Consumo kWh");
                    contentStream.newLineAtOffset(100, 0);
                    contentStream.showText("Valor Total ($)");
                    contentStream.endText();

                    int y = 480;
                    BigDecimal totalFactura = BigDecimal.ZERO;

                    for (Facturacion factura : facturas) {
                        contentStream.beginText();
                        contentStream.newLineAtOffset(50, y);
                        contentStream.showText(String.valueOf(factura.getFacturacion_id()));
                        contentStream.newLineAtOffset(100, 0);
                        contentStream.showText(String.valueOf(factura.getFecha_factura()));
                        contentStream.newLineAtOffset(100, 0);
                        contentStream.showText(String.valueOf(factura.getTotal_kwh()));
                        contentStream.newLineAtOffset(100, 0);

                        BigDecimal valorTotal = factura.getTotal_kwh().multiply(new BigDecimal("600")); // Tarifa de 600 por kWh
                        totalFactura = totalFactura.add(valorTotal);

                        contentStream.showText(String.valueOf(valorTotal));
                        contentStream.endText();

                        y -= 20;
                    }

                    // Total de la factura
                    contentStream.setFont(PDType1Font.TIMES_BOLD, 12);
                    contentStream.beginText();
                    contentStream.newLineAtOffset(50, y - 20);
                    contentStream.showText("Total a pagar: $" + totalFactura);
                    contentStream.endText();
                }

                // Guardar el archivo PDF
                document.save(new File(rutaArchivo));
                System.out.println("Factura generada correctamente en: " + rutaArchivo);

            } catch (IOException e) {
                System.err.println("Error al generar el PDF: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            System.err.println("No se encontró el cliente con el contrato_id: " + contratoId);
        }
    }

    // Método para obtener los datos del cliente desde la base de datos utilizando el contrato_id
    private Cliente obtenerClientePorContratoId(int contratoId) {
        String sql = "SELECT c.* FROM clientes c JOIN contratos ct ON c.cliente_id = ct.clientes_cliente_id WHERE ct.contrato_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, contratoId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Cliente cliente = new Cliente();
                    cliente.setIdCliente(rs.getInt("cliente_id"));
                    cliente.setTipoCliente(rs.getString("tipo_cliente"));
                    cliente.setPrimerNombre(rs.getString("primer_nombre"));
                    cliente.setSegundoNombre(rs.getString("segundo_nombre"));
                    cliente.setPrimerApellido(rs.getString("primer_apellido"));
                    cliente.setSegundoApellido(rs.getString("segundo_apellido"));
                    cliente.setTipoIdentificacion(rs.getString("tipo_identificacion"));
                    cliente.setNUI(rs.getString("NUI"));
                    cliente.setFechaNacimiento(rs.getString("fecha_nacimiento"));
                    cliente.setRazonSocial(rs.getString("razon_social"));
                    cliente.setNIT(rs.getString("NIT"));
                    cliente.setFechaCreacion(rs.getString("fecha_creacion"));
                    cliente.setCelular(rs.getString("celular"));
                    cliente.setCorreo(rs.getString("correo"));
                    cliente.setClienteDireccion(rs.getString("cliente_direccion"));
                    return cliente;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
