package controller;

import model.ValorKWh;
import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ValorKWhController {

    public static void addValorKWh(ValorKWh valorKWh) throws SQLException {
        String sql = "INSERT INTO ValorKWh (Franja_idFranja, valorPiso, valorTecho, fecha) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, valorKWh.getFranja().getIdFranja());
            pstmt.setBigDecimal(2, valorKWh.getValorPiso());
            pstmt.setBigDecimal(3, valorKWh.getValorTecho());
            pstmt.setDate(4, new java.sql.Date(valorKWh.getFecha().getTime()));
            pstmt.executeUpdate();
        }
    }

    public static void updateValorKWh(ValorKWh valorKWh) throws SQLException {
        String sql = "UPDATE ValorKWh SET valorPiso = ?, valorTecho = ?, fecha = ? WHERE idValorKWh = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setBigDecimal(1, valorKWh.getValorPiso());
            pstmt.setBigDecimal(2, valorKWh.getValorTecho());
            pstmt.setDate(3, new java.sql.Date(valorKWh.getFecha().getTime()));
            pstmt.setInt(4, valorKWh.getIdValorKWh());
            pstmt.executeUpdate();
        }
    }
}
