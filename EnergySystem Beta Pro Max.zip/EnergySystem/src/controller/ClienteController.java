package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Cliente;
import util.DatabaseUtil;

public class ClienteController {

    // Métodos genéricos
    public static void addCliente(Cliente cliente) throws SQLException {
        String sql = "INSERT INTO clientes (tipo_cliente, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, tipo_identificacion, NUI, fecha_nacimiento, razon_social, NIT, fecha_creacion, celular, correo, cliente_direccion) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, cliente.getTipoCliente());
            pstmt.setString(2, cliente.getPrimerNombre());
            pstmt.setString(3, cliente.getSegundoNombre());
            pstmt.setString(4, cliente.getPrimerApellido());
            pstmt.setString(5, cliente.getSegundoApellido());
            pstmt.setString(6, cliente.getTipoIdentificacion());
            pstmt.setString(7, cliente.getNUI());
            pstmt.setString(8, cliente.getFechaNacimiento());
            pstmt.setString(9, cliente.getRazonSocial());
            pstmt.setString(10, cliente.getNIT());
            pstmt.setString(11, cliente.getFechaCreacion());
            pstmt.setString(12, cliente.getCelular());
            pstmt.setString(13, cliente.getCorreo());
            pstmt.setString(14, cliente.getClienteDireccion());
            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int idCliente = generatedKeys.getInt(1);
                    cliente.setIdCliente(idCliente);
                }
            }
        }
    }

    public static void deleteCliente(int idCliente) throws SQLException {
        String sql = "DELETE FROM clientes WHERE cliente_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idCliente);
            pstmt.executeUpdate();
        }
    }

    public static List<Map<String, String>> getClientes() throws SQLException {
        String sql = "SELECT * FROM clientes";
        List<Map<String, String>> clientes = new ArrayList<>();
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                Map<String, String> cliente = new HashMap<>();
                cliente.put("id", String.valueOf(rs.getInt("cliente_id")));
                cliente.put("tipo_cliente", rs.getString("tipo_cliente"));
                cliente.put("primer_nombre", rs.getString("primer_nombre"));
                cliente.put("segundo_nombre", rs.getString("segundo_nombre"));
                cliente.put("primer_apellido", rs.getString("primer_apellido"));
                cliente.put("segundo_apellido", rs.getString("segundo_apellido"));
                cliente.put("tipo_identificacion", rs.getString("tipo_identificacion"));
                cliente.put("NUI", rs.getString("NUI"));
                cliente.put("fecha_nacimiento", rs.getString("fecha_nacimiento"));
                cliente.put("razon_social", rs.getString("razon_social"));
                cliente.put("NIT", rs.getString("NIT"));
                cliente.put("fecha_creacion", rs.getString("fecha_creacion"));
                cliente.put("celular", rs.getString("celular"));
                cliente.put("correo", rs.getString("correo"));
                cliente.put("cliente_direccion", rs.getString("cliente_direccion"));
                clientes.add(cliente);
            }
        }
        return clientes;
    }
}



