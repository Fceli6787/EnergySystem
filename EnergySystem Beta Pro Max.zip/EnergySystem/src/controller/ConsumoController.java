package controller;

import model.Consumo;
import util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ConsumoController {

    public static void addConsumo(Consumo consumo) throws SQLException {
        String sql = "INSERT INTO Consumo (fecha, consumoKWh) VALUES (?, ?)";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, new java.sql.Date(consumo.getFecha().getTime()));
            pstmt.setBigDecimal(2, consumo.getConsumoKWh());
            pstmt.executeUpdate();
        }
    }

    public static void updateConsumo(Consumo consumo) throws SQLException {
        String sql = "UPDATE Consumo SET fecha = ?, consumoKWh = ? WHERE idConsumo = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, new java.sql.Date(consumo.getFecha().getTime()));
            pstmt.setBigDecimal(2, consumo.getConsumoKWh());
            pstmt.setInt(3, consumo.getIdConsumo());
            pstmt.executeUpdate();
        }
    }
}
